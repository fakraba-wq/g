import {writeFile,mkdir,mkdtemp,readdir,readFile} from 'node:fs/promises';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {spawn,spawnSync} from 'node:child_process';
import net from 'node:net';
import {fileURLToPath} from 'node:url';
import {existsSync} from 'node:fs';
import assert from 'node:assert/strict';
async function freePort(){const listener=net.createServer();await new Promise(r=>listener.listen(0,'127.0.0.1',r));const port=listener.address().port;await new Promise(r=>listener.close(r));return port;}
const root=fileURLToPath(new URL('../',import.meta.url)), children=[];
const artifacts=join(root,'.test-artifacts');await mkdir(artifacts,{recursive:true});
const work=await mkdtemp(join(tmpdir(),'crimson-browser-suite-'));
const nativePath=join(work,'scanner');
const workspaceGo=fileURLToPath(new URL('../../.tools/go/bin/go',import.meta.url));
const go=process.env.GO_BIN||(existsSync(workspaceGo)?workspaceGo:'go');
const built=spawnSync(go,['build','-o',nativePath,'.'],{cwd:join(root,'client'),env:{...process.env,GOCACHE:process.env.GOCACHE||join(tmpdir(),'sentinel-go-cache'),GOTELEMETRY:'off'},stdio:'inherit'});
assert.equal(built.status,0,'native test scanner build failed');
const port=await freePort(),debugPort=await freePort(),siteURL='http://127.0.0.1:'+port,debug='http://127.0.0.1:'+debugPort;
async function ready(url){for(let i=0;i<200;i++){try{const r=await fetch(url);if(r.ok)return;}catch{}await new Promise(r=>setTimeout(r,50));}throw new Error('Test service did not become ready');}
try {
const server=spawn(process.execPath,['server.js'],{cwd:root,env:{...process.env,PORT:String(port),SENTINEL_DATA_DIR:join(work,'data')},stdio:'ignore'});children.push(server);
await ready(siteURL+'/api/auth/status');
const chrome=spawn(process.env.CHROMIUM_BIN||'chromium',['--headless','--no-sandbox','--disable-gpu','--disable-dev-shm-usage','--user-data-dir='+join(work,'chrome'),'--remote-debugging-port='+debugPort,'--remote-debugging-address=127.0.0.1','about:blank'],{stdio:'ignore'});children.push(chrome);
await ready(debug+'/json');

async function connect(target){const ws=new WebSocket(target.webSocketDebuggerUrl);await new Promise(r=>ws.addEventListener('open',r,{once:true}));let id=0;const waiting=new Map(),errors=[];ws.addEventListener('message',event=>{const m=JSON.parse(event.data);if(m.id){const p=waiting.get(m.id);waiting.delete(m.id);m.error?p.reject(new Error(m.error.message)):p.resolve(m.result);}if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails.exception?.description||m.params.exceptionDetails.text);});const call=(method,params={})=>new Promise((resolve,reject)=>{const n=++id;waiting.set(n,{resolve,reject});ws.send(JSON.stringify({id:n,method,params}));});const evaluate=async expression=>{const r=await call('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});if(r.exceptionDetails)throw new Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value;};const wait=async expression=>{const deadline=Date.now()+15000;while(Date.now()<deadline){if(await evaluate(expression))return;await new Promise(r=>setTimeout(r,60));}throw new Error('Timed out: '+expression);};await call('Runtime.enable');await call('Page.enable');return{ws,call,evaluate,wait,errors};}
const target=(await(await fetch(debug+'/json')).json()).find(t=>t.type==='page');const site=await connect(target);
await site.call('Emulation.setDeviceMetricsOverride',{width:1440,height:1100,deviceScaleFactor:1,mobile:false});
await site.call('Page.navigate',{url:siteURL});
await site.wait("document.getElementById('session-status')?.textContent.includes('Set your password')");
assert.match(await site.evaluate('document.title'),/^Crimson PC Check/);
assert.equal(await site.evaluate("document.querySelector('.brand-logo').naturalWidth>0"),true);
await writeFile(join(artifacts,'dashboard.png'),Buffer.from((await site.call('Page.captureScreenshot',{format:'png',captureBeyondViewport:true})).data,'base64'));
await site.call('Emulation.setDeviceMetricsOverride',{width:393,height:852,deviceScaleFactor:1,mobile:true});
assert.equal(await site.evaluate('document.documentElement.scrollWidth<=innerWidth'),true);
await writeFile(join(artifacts,'mobile.png'),Buffer.from((await site.call('Page.captureScreenshot',{format:'png',captureBeyondViewport:true})).data,'base64'));
await site.call('Emulation.setDeviceMetricsOverride',{width:1440,height:1100,deviceScaleFactor:1,mobile:false});
await site.evaluate("document.getElementById('staff-password').value=Array.from(crypto.getRandomValues(new Uint8Array(24)),x=>x.toString(16).padStart(2,'0')).join('');document.getElementById('staff-form').requestSubmit();");
await site.wait("!document.getElementById('session-controls').hidden && document.getElementById('session-status').textContent.includes('Staff signed in')");
assert.match(await site.evaluate("document.getElementById('create-session').textContent"),/inventory/);
await site.evaluate("document.getElementById('create-session').click()");await site.wait("document.querySelector('.session-code')!==null");
const code=await site.evaluate("document.querySelector('.session-code').textContent");
const folder=await mkdtemp(join(tmpdir(),'crimson-evidence-'));await writeFile(join(folder,'hello.txt'),'hello');
const child=spawn(nativePath,['-server',siteURL,'-code',code,'-no-open'],{stdio:['pipe','pipe','pipe']});children.push(child);let output='';child.stdout.on('data',chunk=>output+=chunk);child.stderr.on('data',chunk=>output+=chunk);
let guiURL;for(let i=0;i<100;i++){guiURL=output.match(/http:\/\/127\.0\.0\.1:\d+\/\?token=[a-f0-9]+/)?.[0];if(guiURL)break;await new Promise(r=>setTimeout(r,50));}assert.ok(guiURL,'native guided server did not start');
const guiTarget=await(await fetch(debug+'/json/new?about:blank',{method:'PUT'})).json();const gui=await connect(guiTarget);
await gui.call('Emulation.setDeviceMetricsOverride',{width:1200,height:1000,deviceScaleFactor:1,mobile:false});await gui.call('Page.navigate',{url:guiURL});
await gui.wait("document.getElementById('code')?.value.length===6");assert.equal(await gui.evaluate("document.getElementById('code').value"),code);
assert.equal(await gui.evaluate("document.getElementById('consent').checked"),false);assert.equal(await gui.evaluate("document.getElementById('processes').checked"),false);
await writeFile(join(artifacts,'guided-scanner.png'),Buffer.from((await gui.call('Page.captureScreenshot',{format:'png',captureBeyondViewport:true})).data,'base64'));
await gui.call('Emulation.setDeviceMetricsOverride',{width:393,height:852,deviceScaleFactor:1,mobile:true});assert.equal(await gui.evaluate('document.documentElement.scrollWidth<=innerWidth'),true);await gui.call('Emulation.setDeviceMetricsOverride',{width:1200,height:1000,deviceScaleFactor:1,mobile:false});
await gui.evaluate(`document.getElementById('folder').value=${JSON.stringify(folder)};document.getElementById('consent').click();document.getElementById('scan-form').requestSubmit();`);
await gui.wait("!document.getElementById('report-card').hidden");assert.equal(await gui.evaluate("document.getElementById('hash-count').textContent"),'1');
assert.equal(await gui.evaluate("document.getElementById('share').disabled"),true);
await gui.evaluate("document.getElementById('share-consent').click();document.getElementById('share').click();");await gui.wait("!document.getElementById('sent').hidden");
await site.call('Page.bringToFront');await site.wait("document.querySelector('.session-row')?.textContent.includes('Report received')");
await site.evaluate("Array.from(document.querySelectorAll('.session-row button')).find(b=>b.textContent==='View report').click()");
assert.match(await site.evaluate("document.getElementById('report-summary').textContent"),/No signature library/);
await site.evaluate("document.querySelector('.signature-editor').open=true;document.getElementById('signature-name').value='Harmless browser test';document.getElementById('signature-hash').value='2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824';document.getElementById('signature-source').value='Known hello test vector';document.getElementById('signature-category').value='test';document.getElementById('signature-form').requestSubmit();document.getElementById('save-library').click()");
await site.wait("document.getElementById('signature-status').textContent.includes('Library saved')");
await site.evaluate("document.getElementById('reanalyze-report').click()");await site.wait("document.getElementById('report-summary').textContent.includes('Re-analyzed')");
assert.match(await site.evaluate("document.getElementById('result-rows').textContent"),/Harmless test match/);
assert.match(await site.evaluate("document.getElementById('stat-matches').textContent"),/^0/);
await site.evaluate("document.getElementById('original-report').click()");assert.match(await site.evaluate("document.getElementById('result-rows').textContent"),/Unverified/);
await site.evaluate("document.getElementById('reanalyze-report').click()");await site.wait("document.getElementById('report-summary').textContent.includes('Re-analyzed')");
await site.evaluate("document.getElementById('result-search').value='does-not-exist';document.getElementById('result-search').dispatchEvent(new Event('input'));");assert.match(await site.evaluate("document.getElementById('result-rows').textContent"),/No files match/);
await site.evaluate("document.getElementById('result-search').value='';document.getElementById('result-search').dispatchEvent(new Event('input'));document.getElementById('result-filter').value='test';document.getElementById('result-filter').dispatchEvent(new Event('change'));");assert.match(await site.evaluate("document.getElementById('result-count').textContent"),/1 \/ 1/);
const downloads=join(work,'downloads');await mkdir(downloads,{recursive:true});await site.call('Browser.setDownloadBehavior',{behavior:'allow',downloadPath:downloads});
await site.evaluate("document.getElementById('export-report').click()");await site.evaluate("document.getElementById('create-session').click()");await site.wait("document.querySelectorAll('.session-row').length===2");
await site.evaluate("Array.from(document.querySelectorAll('.session-row button')).find(b=>b.textContent==='Guided scanner').click()");
await site.wait("document.getElementById('session-status').textContent.includes('Guided scanner downloaded')");
let names;for(let i=0;i<100;i++){names=await readdir(downloads);if(names.some(n=>n.endsWith('.exe'))&&names.some(n=>n.endsWith('.json')))break;await new Promise(r=>setTimeout(r,50));}
const personalized=await readFile(join(downloads,names.find(n=>n.endsWith('.exe'))));assert.equal(personalized.subarray(-8).toString(),'CRMSNCFG');const length=personalized.readUInt32LE(personalized.length-12);const config=JSON.parse(personalized.subarray(personalized.length-12-length,personalized.length-12));assert.equal(config.server,siteURL);assert.match(config.code,/^\d{6}$/);assert.equal(personalized.subarray(0,2).toString(),'MZ');
const report=JSON.parse(await readFile(join(downloads,names.find(n=>n.endsWith('.json'))),'utf8'));assert.equal(report.results[0].status,'test');
await site.call('Page.reload');await site.wait("document.getElementById('library-caption')?.textContent.includes('Saved revision 1')");assert.match(await site.evaluate("document.getElementById('stat-signatures').textContent"),/^1/);
await gui.evaluate("document.getElementById('quit').click()");await gui.wait("document.getElementById('message').textContent.includes('Scanner fermé')");if(child.exitCode===null)await new Promise(r=>child.once('close',r));
assert.deepEqual(site.errors,[]);assert.deepEqual(gui.errors,[]);console.log('PASS: Crimson branding/logo, desktop/mobile layout, native guided wizard with explicit consent, real folder hash upload, automatic session refresh, persistent library, re-analysis retaining original evidence, search/filter, JSON export and personalized EXE footer. Zero browser runtime exceptions.');site.ws.close();gui.ws.close();

} finally { for(const child of children.reverse()){if(child.exitCode===null&&child.signalCode===null)child.kill('SIGTERM');} }
