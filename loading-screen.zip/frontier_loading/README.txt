FRONTIER — Original western loading screen

CONTENTS
frontier-2min.mp4: 120-second, 1280x720, 24 fps original illustrated landscape with slow camera movement and original synthesized instrumental music. No gameplay or YouTube footage.
index.html: responsive loading-screen overlay, floating dust, audio controls, and real loadProgress events.
background.png: original generated western artwork.

INSTALL REDM
1. Extract this folder into your server's resources folder as frontier_loading.
2. Add: ensure frontier_loading
   to server.cfg, and disable any other loading-screen resource.
3. Restart the server and test a connection.

CUSTOMIZE
Open index.html and change SERVER_NAME and SUBTITLE in its script.
Music starts muted because browsers can require a user gesture. Click ENABLE MUSIC to hear it.
In a normal browser, the progress bar waits for actual server loading events; it is intentionally not a fake timer.
The standalone MP4 includes music but no server-name text so it can be reused.

VALIDATION
Video/audio duration and browser interface are checked locally. Actual in-game RedM startup cannot be tested in this Linux environment; verify on your server before production use.
The soundtrack is a simple original synthesized western-style composition, not an official Red Dead recording.
